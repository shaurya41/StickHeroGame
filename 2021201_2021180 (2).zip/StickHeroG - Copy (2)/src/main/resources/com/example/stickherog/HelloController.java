package com.example.stickherog;

public class HelloController {
}
