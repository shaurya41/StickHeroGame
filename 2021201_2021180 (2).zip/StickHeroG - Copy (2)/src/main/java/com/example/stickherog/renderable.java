package com.example.stickherog;

import javafx.scene.canvas.GraphicsContext;

public interface renderable {
    void render(GraphicsContext gc,double cameraOffset);

}
