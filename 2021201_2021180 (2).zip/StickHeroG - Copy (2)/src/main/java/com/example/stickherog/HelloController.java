// StartScreenController.java
//package com.example.stickherog;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//
//public class HelloController{
//
//    @FXML
//    private void startGame(ActionEvent event) {
//        // Handle the start game action
//        // You can transition to the main game scene here
//        HelloApplication.startGame();
//    }
//}
