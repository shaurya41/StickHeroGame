//package com.example.stickherog;
//
//import javafx.scene.canvas.GraphicsContext;
//import javafx.scene.paint.Color;
//
//public class Pillar extends Platform {
//    public Pillar(double x, double y, double width, double height) {
//        super(x, y, width, height);
//    }
//
//    // Additional methods or customization specific to Pillar can be added here
//
//    @Override
//    public void render(GraphicsContext gc) {
//        // Customize rendering for Pillar if needed
//        gc.setFill(Color.BROWN);
//        gc.fillRect(getX(), getY(), getWidth(), getHeight());
//    }
//}
